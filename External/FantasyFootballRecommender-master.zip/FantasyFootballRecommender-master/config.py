CONSUMER_KEY = 
CONSUMER_SECRET = 
ACCESS_KEY = 
ACCESS_SECRET = 

TRAINING_PATH = 'app/static/Training/'
TRAINING_REVIEW_PATH = 'app/static/TrainingReview/'
TEST_PATH = 'app/static/Test/'
STOPWORDS = ['a','about','after','am','an','and','any','as','at','be','because','been','by','both','but','during','each','between','being','did','do','does','doing','for','from','further','had','has','have','he','hed','hell','hes','her','here','heres','hers','herself','him','himself','his','how','hows','i','im','id','ill','having','ive','if','in','into','is','it','its','its','itself','lets','me','my','myself','of','on','or','our','ours','ourselves','own','same','she','shed','shell','shes','so','such','than','that','thats','the','their','theirs','them','themselves','then','there','theres','these','they','theyd','theyll','theyre','theyve','this','those','through','to','too','very','was','we','wed','well','were','weve','were','what','whats','when','whens','where','wheres','which','while','who','whos','whom','why','whys','with','you','youd','youll','youre','youve','your','yours','yourself','yourselves','quarterback','qb','qbs','rb','rbs','receiver','wr','wrs','te','tes','k','ks','kicker','fantasy','football','team','points','nfl']
MAX_TWEETS = 200
